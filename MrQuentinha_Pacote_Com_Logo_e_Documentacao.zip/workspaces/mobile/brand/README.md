# Tema (Mobile)

- Use `theme.ts` como base.
- Para alternar dark/light: usar preferências do sistema e aplicar nos componentes.
- Ícones/Logo: usar os PNG em `assets/brand/png/` (1024/512).
