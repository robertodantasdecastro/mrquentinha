# Brand tokens (Web)

Copie/importe `tokens.css` para o seu projeto web e aplique em `:root`.
Para dark mode, use `data-theme="dark"` no `html` ou `body`.
