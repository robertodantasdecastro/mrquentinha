# Changelog (por sprint)

## Sprint 0
- Marca oficial definida: Mr Quentinha (assets/brand/)

- Documentação inicial criada
- Regras do Codex definidas em `AGENTS.md`

> Atualize a cada sprint com o que foi entregue.
