# ADR-XXXX: Título

## Status
Proposto | Aceito | Rejeitado | Substituído

## Contexto
Explique o problema e o que motivou a decisão.

## Decisão
O que foi decidido.

## Consequências
Impactos positivos e negativos. Trade-offs.

## Alternativas consideradas
Opção A, Opção B, etc.
