# Prompt — Bugfix (mínimo patch)

Bug:
- <descreva comportamento atual>
Esperado:
- <descreva esperado>

Forneço logs:
- <cole stacktrace/comando>

Pedido:
- Corrija com o menor patch possível
- Adicione teste de regressão
- Explique causa raiz
