# Prompt — Implementar Feature (padrão)

Implementar a feature: <NOME>

Requisitos:
- <liste requisitos>
- Permissões (roles):
  - <quem pode acessar o quê>

Entregas:
- Modelos + migrações
- Serializers + Views + URLs
- Testes (unit + API)
- Documentação (CHANGELOG + DECISIONS/ADR se necessário)

Como testar:
- <comandos>
