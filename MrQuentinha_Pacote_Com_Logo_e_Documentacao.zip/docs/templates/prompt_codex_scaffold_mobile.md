# Prompt — Scaffold Mobile (React Native)

Tarefa: criar o esqueleto do app mobile em `workspaces/mobile/`.

Entregas:
1) Projeto React Native (Expo recomendado no MVP)
2) Fluxo de login (stub) + tela inicial listando cardápio (mock primeiro)
3) Service layer para API
4) README de build Android (APK)

DoD:
- roda em emulador Android
- estrutura pronta para consumir API real
