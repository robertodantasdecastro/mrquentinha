# Checklist rápido de segurança (por feature)

- [ ] Endpoint exige autenticação?
- [ ] Permissões por role estão corretas?
- [ ] Validação de input cobre casos inválidos?
- [ ] Não há dados sensíveis em logs?
- [ ] Não há segredos/versionamento de chaves no repo?
- [ ] Teste de acesso negado existe?
