# Assets de Marca — Mr Quentinha

Arquivos oficiais:
- `logo_wordmark.svg` — logo principal com nome (horizontal)
- `icon_symbol.svg` — símbolo (uso em favicon, marca d’água, etc.)
- `icon_app.svg` — ícone do app (com fundo laranja)
- `tokens.css` / `tokens.json` — tokens de identidade (cores, radius, etc.)

PNG com transparência são gerados em `png/`.

## Raster original (referência)
- `original_png/` contém recortes do modelo escolhido (PNG com transparência no fundo branco).
